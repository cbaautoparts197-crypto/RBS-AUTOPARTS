# -*- coding: utf-8 -*-
import re
import sys

# 设置UTF-8输出
if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')

with open('index-v2.html', 'r', encoding='utf-8') as f:
    content = f.read()
    lines = content.split('\n')

# 找出所有div的开始和结束
stack = []
errors = []

for i, line in enumerate(lines, 1):
    # 找出这一行所有的<div>和</div>
    opens = len(re.findall(r'<div\b[^>]*>', line))
    closes = len(re.findall(r'</div>', line))
    
    # 记录位置
    for _ in range(opens):
        stack.append((i, line.strip()[:80]))
    
    for _ in range(closes):
        if stack:
            stack.pop()
        else:
            errors.append(f'Line {i}: 多余的</div>')

# 输出未闭合的div
print(f'总行数: {len(lines)}')
print(f'未闭合div数量: {len(stack)}')
print()
if stack:
    print('未闭合的div位置:')
    for i, (line_num, line_preview) in enumerate(stack[:30], 1):
        print(f'{i}. Line {line_num}: {line_preview}...')

if errors:
    print('多余的闭合div:')
    for err in errors[:10]:
        print(err)
