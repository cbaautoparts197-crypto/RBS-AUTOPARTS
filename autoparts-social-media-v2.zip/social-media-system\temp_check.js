﻿
function showPage(pageId, e) {
document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
document.getElementById('page-' + pageId).classList.add('active');
var evt = e || window.event;
if(evt && evt.target) {
var navItem = evt.target.closest('.nav-item');
if(navItem) navItem.classList.add('active');
}
const titles = {dashboard:'浠〃鐩?,accounts:'璐﹀彿绠＄悊',creator:'鍐呭鍒涗綔',calendar:'鍙戝竷鏃ュ巻',analytics:'鏁版嵁鍒嗘瀽',team:'鍥㈤槦鍗忎綔',assets:'绱犳潗搴?,products:'浜у搧绠＄悊',api:'API绠＄悊',inquiries:'璇㈢洏绠＄悊',messages:'娑堟伅涓績',competitors:'绔炲搧鐩戞帶',workflow:'宸ヤ綔娴?};
document.getElementById('headerTitle').textContent = titles[pageId];
}
function showModal(id) { document.getElementById('modal-' + id).classList.add('active'); }
function hideModal(id) { document.getElementById('modal-' + id).classList.remove('active'); }
function closeModal(e) { if(e.target.classList.contains('modal-overlay')) e.target.classList.remove('active'); }
function showToast(msg, type) {
const t = document.createElement('div');
t.className = 'toast ' + type;
t.innerHTML = '<span>' + (type==='success'?'鉁?:'鉁?) + '</span><span>' + msg + '</span>';
document.getElementById('toastContainer').appendChild(t);
setTimeout(() => t.remove(), 4000);
}
function toggleChip(el) { el.classList.toggle('selected'); }
function setContentType(type, e) {
document.querySelectorAll('.tool-btn').forEach(b => b.classList.remove('active'));
var evt = e || window.event;
if(evt && evt.target) evt.target.classList.add('active');
}
function aiGenerate() {
const output = document.getElementById('aiOutput');
const body = document.getElementById('contentBody');
output.style.display = 'block';
output.innerHTML = '<div class="loading"><div class="spinner"></div><span>AI 姝ｅ湪鐢熸垚鍐呭...</span></div>';
setTimeout(() => {
const content = '瀹㈡埛瑙佽瘉\n\n"杩囧幓6涓湀锛屾垜浠洜 Engine Mount 璐ㄩ噺闂鏀跺埌浜嗚秴杩?0璧峰鎴锋姇璇夈€傝嚜浠庢洿鎹緵搴斿晢鍚庯紝鎶曡瘔褰掗浂锛屽璐巼鎻愬崌浜?5%锛?\n\n鈥斺€?寰峰浗鏌愬ぇ鍨嬫苯閰嶅垎閿€鍟嗛噰璐粡鐞?Michael\n\n涓轰粈涔堥€夋嫨鎴戜滑鐨?Engine Mount锛焅n鈥?閲囩敤浼樿川澶╃劧姗¤兌锛岃€愭补鑰愯€佸寲\n鈥?绮惧瘑閲戝睘楠ㄦ灦锛屾壙杞藉姏鎻愬崌40%\n鈥?閫氳繃ISO/TS16949璁よ瘉锛孫E鍝佽川淇濊瘉\n鈥?閫傞厤涓绘祦杞﹀瀷锛氫赴鐢般€佹湰鐢般€佸ぇ浼椼€佸疂椹瓑\n\n#EngineMount #AutoParts #B2B #Automotive';
output.innerHTML = content;
body.value = content;
document.getElementById('contentTitle').value = 'Engine Mount 瀹㈡埛鎴愬姛妗堜緥';
showToast('鍐呭鐢熸垚鎴愬姛锛?, 'success');
}, 2000);
}
function connectAccount(platform, e) {
var evt = e || window.event;
var btn = evt ? evt.target : null;
if(btn) {
btn.innerHTML = '杩炴帴涓?..';
btn.disabled = true;
setTimeout(() => {
btn.innerHTML = '杩炴帴璐﹀彿';
btn.disabled = false;
showToast(platform + ' 璐﹀彿杩炴帴鎴愬姛锛?, 'success');
}, 1500);
}
}
function testAccount(platform) { showToast(platform + ' 杩炴帴娴嬭瘯鎴愬姛锛?, 'success'); }
function saveContent() { showToast('鑽夌宸蹭繚瀛?, 'success'); }
function scheduleContent() { showToast('宸叉坊鍔犲埌鍙戝竷闃熷垪', 'success'); }
function publishNow() { showToast('鍐呭鍙戝竷鎴愬姛锛?, 'success'); }
function changeMonth(dir) { showToast(dir > 0 ? '涓嬩釜鏈? : '涓婁釜鏈?, 'success'); }
// 绱犳潗搴撳姛鑳?function browsePath(type) { showToast('璇烽€夋嫨' + type + '鐩綍', 'success'); }
function syncCloud() { showToast('浜戠绱犳潗鍚屾涓?..', 'success'); }
function refreshAssets() { showToast('绱犳潗搴撳凡鍒锋柊', 'success'); }
function filterAssets(type, e) {
document.querySelectorAll('.asset-toolbar .tool-btn').forEach(b => b.classList.remove('active'));
var evt = e || window.event;
if(evt && evt.target) evt.target.classList.add('active');
showToast('绛涢€? ' + type, 'success');
}
function previewAsset(id) { showToast('棰勮绱犳潗: ' + id, 'success'); }
// API绠＄悊鍔熻兘
function clearLogs() { showToast('鏃ュ織宸叉竻绌?, 'success'); }
function exportLogs() { showToast('鏃ュ織瀵煎嚭鎴愬姛', 'success'); }
function saveApiConfig() { showToast('API閰嶇疆宸蹭繚瀛?, 'success'); }
// 浜у搧绠＄悊鍔熻兘
function showProductDetail(id) { showModal('productDetail'); }
function addProduct() { showModal('addProduct'); }

// 绱犳潗绠＄悊鍔熻兘
function browsePath(type) {
const paths = {
root: 'D:\\AutoParts\\assets\\',
products: 'D:\\AutoParts\\assets\\products\\',
videos: 'D:\\AutoParts\\assets\\videos\\',
brand: 'D:\\AutoParts\\assets\\brand\\',
testimonials: 'D:\\AutoParts\\assets\\testimonials\\',
docs: 'D:\\AutoParts\\assets\\docs\\',
templates: 'D:\\AutoParts\\assets\\templates\\'
};
showToast('娴忚: ' + (paths[type] || type), 'info');
}
function syncCloud() { showToast('姝ｅ湪鍚屾浜戠绱犳潗搴?..', 'info'); setTimeout(() => showToast('鍚屾瀹屾垚锛屾柊澧?12 涓礌鏉?, 'success'), 2000); }
function refreshAssets() { showToast('姝ｅ湪鎵弿绱犳潗搴?..', 'info'); setTimeout(() => showToast('鎵弿瀹屾垚锛屽叡 293 涓礌鏉?, 'success'), 1500); }
function importAssets() { showModal('importAssets'); }
function previewAsset(id) { showModal('assetPreview'); }
function searchAssets(query) { if(query.length > 2) showToast('鎼滅储: ' + query, 'info'); }
function loadMoreAssets() { showToast('鍔犺浇鏇村绱犳潗...', 'info'); }
function testPath() { showToast('杩炴帴娴嬭瘯鎴愬姛', 'success'); }
function useAsset() { hideModal('assetPreview'); showToast('绱犳潗宸叉坊鍔犲埌缂栬緫鍣?, 'success'); }

// 鍥㈤槦鏉冮檺鍔熻兘
function showMemberDetail(id) { showModal('memberDetail'); }
function loadRolePermissions(role) { showToast('宸插姞杞?' + role + ' 瑙掕壊鏉冮檺', 'info'); }
function loadMoreLogs() { showToast('鍔犺浇鏇村鏃ュ織...', 'info'); }

// 鍐呭妯℃澘鍔熻兘
function applyTemplate(id) {
const templates = {
'product-launch': {title: '馃殌 {浜у搧鍚峿 姝ｅ紡涓婂競锛?, body: '鎴戜滑寰堥珮鍏村湴瀹ｅ竷 {浜у搧鍚峿 鐜板凡涓婂競锛乗n\n鉁?鏍稿績鐗圭偣锛歕n鈥?鐗圭偣1\n鈥?鐗圭偣2\n鈥?鐗圭偣3\n\n馃摝 閫傞厤杞﹀瀷锛歿杞﹀瀷鍒楄〃}\n馃挵 鎵瑰彂浠锋牸锛氳仈绯绘垜浠幏鍙栨渶浼樻姤浠穃n\n#AutoParts #B2B #{浜у搧鍚峿'},
'promotion': {title: '馃帀 闄愭椂浼樻儬娲诲姩', body: '馃敟 {娲诲姩鍚嶇О} 寮€濮嬪暒锛乗n\n鈴?娲诲姩鏃堕棿锛歿寮€濮嬫棩鏈焳 - {缁撴潫鏃ユ湡}\n馃挵 浼樻儬鍔涘害锛歿鎶樻墸淇℃伅}\n\n閫傜敤浜у搧锛歕n鈥?{浜у搧1}\n鈥?{浜у搧2}\n\n绔嬪嵆璇环鑾峰彇涓撳睘浼樻儬锛乗n#淇冮攢 #浼樻儬 #AutoParts'},
'tech-tutorial': {title: '馃摎 {浜у搧鍚峿 瀹夎鎸囧崡', body: '浠婂ぉ涓哄ぇ瀹跺甫鏉?{浜у搧鍚峿 鐨勪笓涓氬畨瑁呮暀绋嬶細\n\n馃敡 鎵€闇€宸ュ叿锛歕n鈥?宸ュ叿1\n鈥?宸ュ叿2\n\n馃搵 瀹夎姝ラ锛歕n1. 姝ラ涓€\n2. 姝ラ浜孿n3. 姝ラ涓塡n\n鈿狅笍 娉ㄦ剰浜嬮」锛歕n鈥?娉ㄦ剰鐐?\n鈥?娉ㄦ剰鐐?\n\n#瀹夎鏁欑▼ #鎶€鏈垎浜?#{浜у搧鍚峿'},
'testimonial': {title: '馃挰 瀹㈡埛濂借瘎鍒嗕韩', body: '鎰熻阿鏉ヨ嚜 {瀹㈡埛鍦板尯} 鐨?{瀹㈡埛鍚嶇О} 鍒嗕韩锛歕n\n"{璇勪环鍐呭}"\n\n馃搳 閲囪喘淇℃伅锛歕n鈥?浜у搧锛歿浜у搧鍚峿\n鈥?鏁伴噺锛歿閲囪喘鏁伴噺}\n鈥?鍚堜綔鏃堕暱锛歿鍚堜綔鏃堕暱}\n\n鏈熷緟涓庢洿澶氬鎴峰缓绔嬮暱鏈熷悎浣滐紒\n#瀹㈡埛瑙佽瘉 #B2B鍚堜綔'}
};
const t = templates[id];
if(t) {
document.getElementById('contentTitle').value = t.title;
document.getElementById('contentBody').value = t.body;
hideModal('templates');
showToast('妯℃澘宸插簲鐢?, 'success');
}
}
function setPreviewPlatform(platform, el) {
document.querySelectorAll('.chip-group:first-child .chip').forEach(c => c.classList.remove('on'));
el.classList.add('on');
showToast('鍒囨崲鍒?' + platform + ' 棰勮', 'info');
}
function setPreviewDevice(device, el) {
document.querySelectorAll('.chip-group:last-child .chip').forEach(c => c.classList.remove('on'));
el.classList.add('on');
showToast('鍒囨崲鍒? + (device === 'mobile' ? '绉诲姩绔? : '妗岄潰绔?) + '棰勮', 'info');
}
function capturePreview() { showToast('棰勮鎴浘宸蹭繚瀛?, 'success'); }
function publishContent() { hideModal('preview'); showToast('鍐呭宸插彂甯冨埌閫夊畾骞冲彴', 'success'); }

// 瀹氭椂浠诲姟绠＄悊
function updateCronPreview() {
const type = document.getElementById('taskType').value;
document.getElementById('onceConfig').style.display = type === 'once' ? 'block' : 'none';
document.getElementById('repeatConfig').style.display = ['daily','weekly','monthly'].includes(type) ? 'block' : 'none';
document.getElementById('cronConfig').style.display = type === 'custom' ? 'block' : 'none';
if(type === 'weekly') document.getElementById('repeatDayLabel').textContent = '鎵ц鏃ユ湡(鍛?';
else if(type === 'monthly') document.getElementById('repeatDayLabel').textContent = '鎵ц鏃ユ湡(鏈?';
}
function saveTask() {
hideModal('scheduleTask');
showToast('瀹氭椂浠诲姟宸插垱寤?, 'success');
}
function editTask(id) { showModal('scheduleTask'); }
function cancelTask(id) { showToast('浠诲姟 #' + id + ' 宸插彇娑?, 'info'); }
function pauseTask(id) { showToast('浠诲姟 #' + id + ' 宸叉殏鍋?, 'info'); }
function viewTaskLog(id) { showModal('taskLog'); }
function retryTask(id) { showToast('浠诲姟 #' + id + ' 閲嶆柊鎵ц涓?..', 'info'); }
function rerunTask(id) { showToast('浠诲姟 #' + id + ' 閲嶆柊鎵ц涓?..', 'info'); }
function refreshTasks() { showToast('浠诲姟鍒楄〃宸插埛鏂?, 'success'); }

// 澶氳瑷€鏀寔
const translations = {
zh: {dashboard:'浠〃鐩?,accounts:'璐﹀彿绠＄悊',creator:'鍐呭鍒涗綔',calendar:'鍙戝竷鏃ュ巻',analytics:'鏁版嵁鍒嗘瀽',team:'鍥㈤槦鍗忎綔',assets:'绱犳潗搴?,products:'浜у搧绠＄悊',api:'API绠＄悊',newContent:'鏂板缓鍐呭',help:'甯姪',exposure:'鎬绘洕鍏夐噺',interaction:'鎬讳簰鍔ㄩ噺',rate:'浜掑姩鐜?,inquiry:'璇㈢洏杞寲'},
en: {dashboard:'Dashboard',accounts:'Accounts',creator:'Creator',calendar:'Calendar',analytics:'Analytics',team:'Team',assets:'Assets',products:'Products',api:'API',newContent:'New Content',help:'Help',exposure:'Total Exposure',interaction:'Interactions',rate:'Engagement Rate',inquiry:'Inquiries'},
de: {dashboard:'Dashboard',accounts:'Konten',creator:'Ersteller',calendar:'Kalender',analytics:'Analytik',team:'Team',assets:'Materialien',products:'Produkte',api:'API',newContent:'Neuer Inhalt',help:'Hilfe',exposure:'Gesamtansichten',interaction:'Interaktionen',rate:'Engagement',inquiry:'Anfragen'},
ar: {dashboard:'賱賵丨丞 丕賱賯賷丕丿丞',accounts:'丕賱丨爻丕亘丕鬲',creator:'丕賱賲賳卮卅',calendar:'丕賱鬲賯賵賷賲',analytics:'丕賱鬲丨賱賷賱丕鬲',team:'丕賱賮乇賷賯',assets:'丕賱賲賵丕丿',products:'丕賱賲賳鬲噩丕鬲',api:'API',newContent:'賲丨鬲賵賶 噩丿賷丿',help:'賲爻丕毓丿丞',exposure:'廿噩賲丕賱賷 丕賱賲卮丕賴丿丕鬲',interaction:'鬲賮丕毓賱丕鬲',rate:'賲毓丿賱 丕賱鬲賮丕毓賱',inquiry:'丕賱丕爻鬲賮爻丕乇丕鬲'}
};
let currentLang = 'zh';
function changeLang(lang) {
currentLang = lang;
const t = translations[lang];
document.getElementById('headerTitle').textContent = t.dashboard;
document.querySelectorAll('.nav-item span:last-child').forEach((el,i) => {
const keys = ['dashboard','accounts','creator','calendar','analytics','team','assets','products','api'];
if(keys[i]) el.textContent = t[keys[i]];
});
document.querySelectorAll('.stat-label').forEach((el,i) => {
const keys = ['exposure','interaction','rate','inquiry'];
if(keys[i]) el.textContent = t[keys[i]];
});
document.querySelector('.btn.btn-primary').textContent = '+ ' + t.newContent;
showToast('璇█宸插垏鎹?, 'success');
}

// Canvas 鍥捐〃缁樺埗
function drawLineChart(canvasId, labels, data, color) {
const canvas = document.getElementById(canvasId);
if (!canvas) return;
const ctx = canvas.getContext('2d');
const w = canvas.width = canvas.offsetWidth;
const h = canvas.height = canvas.offsetHeight;
const pad = 40;
const maxVal = Math.max(...data) * 1.2;
ctx.clearRect(0,0,w,h);
ctx.strokeStyle = '#334155';
ctx.lineWidth = 1;
ctx.beginPath();
for(let i=0;i<=4;i++){const y=pad+(h-2*pad)*i/4;ctx.moveTo(pad,y);ctx.lineTo(w-pad,y);}
ctx.stroke();
ctx.strokeStyle = color;
ctx.lineWidth = 2;
ctx.beginPath();
data.forEach((v,i) => {
const x = pad + (w-2*pad) * i / (data.length-1);
const y = h - pad - (h-2*pad) * v / maxVal;
i === 0 ? ctx.moveTo(x,y) : ctx.lineTo(x,y);
});
ctx.stroke();
ctx.fillStyle = color;
data.forEach((v,i) => {
const x = pad + (w-2*pad) * i / (data.length-1);
const y = h - pad - (h-2*pad) * v / maxVal;
ctx.beginPath(); ctx.arc(x,y,4,0,Math.PI*2); ctx.fill();
});
ctx.fillStyle = '#94a3b8';
ctx.font = '11px sans-serif';
ctx.textAlign = 'center';
labels.forEach((l,i) => {
const x = pad + (w-2*pad) * i / (labels.length-1);
ctx.fillText(l, x, h-12);
});
}

function drawPieChart(canvasId, data, labels, colors) {
const canvas = document.getElementById(canvasId);
if (!canvas) return;
const ctx = canvas.getContext('2d');
const w = canvas.width = canvas.offsetWidth;
const h = canvas.height = canvas.offsetHeight;
const cx = w/2, cy = h/2, r = Math.min(w,h)/2 - 40;
const total = data.reduce((a,b) => a+b, 0);
let startAngle = -Math.PI/2;
data.forEach((v,i) => {
const angle = v/total * Math.PI*2;
ctx.beginPath();
ctx.moveTo(cx,cy);
ctx.arc(cx,cy,r,startAngle,startAngle+angle);
ctx.closePath();
ctx.fillStyle = colors[i];
ctx.fill();
startAngle += angle;
});
ctx.fillStyle = '#e2e8f0';
ctx.font = '11px sans-serif';
ctx.textAlign = 'left';
let legendY = 20;
data.forEach((v,i) => {
ctx.fillStyle = colors[i];
ctx.fillRect(10, legendY-8, 12, 12);
ctx.fillStyle = '#e2e8f0';
ctx.fillText(labels[i] + ' ' + Math.round(v/total*100) + '%', 28, legendY);
legendY += 18;
});
}

function drawBarChart(canvasId, labels, data, colors) {
const canvas = document.getElementById(canvasId);
if (!canvas) return;
const ctx = canvas.getContext('2d');
const w = canvas.width = canvas.offsetWidth;
const h = canvas.height = canvas.offsetHeight;
const pad = 40;
const maxVal = Math.max(...data) * 1.2;
const barW = (w-2*pad) / data.length - 10;
ctx.clearRect(0,0,w,h);
data.forEach((v,i) => {
const x = pad + i * ((w-2*pad)/data.length) + 5;
const barH = (h-2*pad) * v / maxVal;
const y = h - pad - barH;
ctx.fillStyle = colors[i % colors.length];
ctx.beginPath();
ctx.roundRect(x, y, barW, barH, 4);
ctx.fill();
ctx.fillStyle = '#94a3b8';
ctx.font = '10px sans-serif';
ctx.textAlign = 'center';
ctx.fillText(labels[i], x + barW/2, h-12);
});
}

function drawHorizontalBarChart(canvasId, labels, data, color) {
const canvas = document.getElementById(canvasId);
if (!canvas) return;
const ctx = canvas.getContext('2d');
const w = canvas.width = canvas.offsetWidth;
const h = canvas.height = canvas.offsetHeight;
const pad = 60;
const maxVal = Math.max(...data) * 1.2;
const barH = (h-pad) / data.length - 8;
ctx.clearRect(0,0,w,h);
data.forEach((v,i) => {
const y = 10 + i * ((h-pad)/data.length);
const barW = (w-pad-20) * v / maxVal;
ctx.fillStyle = '#475569';
ctx.font = '11px sans-serif';
ctx.textAlign = 'right';
ctx.fillText(labels[i], pad-5, y + barH/2 + 4);
ctx.fillStyle = color;
ctx.beginPath();
ctx.roundRect(pad, y, barW, barH, 3);
ctx.fill();
ctx.fillStyle = '#e2e8f0';
ctx.textAlign = 'left';
ctx.fillText(v + 'K', pad + barW + 5, y + barH/2 + 4);
});
}

// 鐢ㄦ埛鏁版嵁闅旂绯荤粺
const currentUser = {id:'zhang',name:'寮犵粡鐞?,avatar:'寮?};
function switchUser(userId, e) {
const users = {
zhang:{id:'zhang',name:'寮犵粡鐞?,avatar:'寮?,color:'#3b82f6'},
li:{id:'li',name:'鏉庣紪杈?,avatar:'鏉?,color:'#10b981'},
wang:{id:'wang',name:'鐜嬭璁?,avatar:'鐜?,color:'#f59e0b'},
chen:{id:'chen',name:'闄堝鏍?,avatar:'闄?,color:'#8b5cf6'}
};
currentUser.id = users[userId].id;
currentUser.name = users[userId].name;
currentUser.avatar = users[userId].avatar;
document.getElementById('currentUserName').textContent = currentUser.name;
document.getElementById('currentUserAvatar').textContent = currentUser.avatar;
document.querySelectorAll('.user-list-item').forEach(el => el.classList.remove('active'));
var evt = e || window.event;
if(evt && evt.target) {
var listItem = evt.target.closest('.user-list-item');
if(listItem) listItem.classList.add('active');
}
loadUserData();
hideModal('userSwitch');
showToast('宸插垏鎹㈢敤鎴? ' + currentUser.name, 'success');
}
// 鏁版嵁瀛樺偍浣跨敤鐢ㄦ埛鍓嶇紑闅旂
function saveData(key, value) {
const storageKey = 'autoparts_' + currentUser.id + '_' + key;
localStorage.setItem(storageKey, JSON.stringify(value));
}
function loadData(key) {
const storageKey = 'autoparts_' + currentUser.id + '_' + key;
const data = localStorage.getItem(storageKey);
return data ? JSON.parse(data) : null;
}
function loadUserData() {
console.log('鍔犺浇鐢ㄦ埛鏁版嵁:', currentUser.name);
// 鍙互鍦ㄨ繖閲屽姞杞界敤鎴风壒瀹氱殑鏁版嵁
}
// 澶氳瑷€缈昏瘧绯荤粺
const translations = {};
function applyTranslations() {
const source = document.getElementById('translateSource').value;
const targetLangs = ['en','de','es','pt','ru','ar'];
translations[currentUser.id] = {
source: source,
en: 'Our Engine Mount products feature premium rubber compounds for superior vibration dampening.',
de: 'Unsere Motorlager zeichnen sich durch hochwertige Gummimischungen aus.',
es: 'Nuestros soportes de motor cuentan con compuestos de caucho premium.',
pt: 'Nossos suportes de motor apresentam compostos de borracha premium.',
ru: '袧邪褕懈 芯锌芯褉褘 写胁懈谐邪褌械谢褟 懈蟹谐芯褌芯胁谢械薪褘 懈蟹 锌褉械屑懈邪谢褜薪褘褏 褉械蟹懈薪芯胁褘褏 泻芯屑锌邪褍薪写芯胁.',
ar: '賲賳鬲噩丕鬲 丨丕賲賱 丕賱賲丨乇賰 丕賱禺丕氐丞 亘賳丕 賲氐賳賵毓丞 賲賳 賲乇賰亘丕鬲 丕賱賲胤丕胤 丕賱賮丕禺乇丞.'
};
showTranslationList();
hideModal('translate');
showToast('缈昏瘧宸插簲鐢ㄥ埌鍐呭', 'success');
}
function showTranslationList() {
const list = document.getElementById('translationList');
if(!list) return;
const langs = {'en':'馃嚞馃嚙 English','de':'馃嚛馃嚜 Deutsch','es':'馃嚜馃嚫 Espa帽ol','pt':'馃嚙馃嚪 Portugu锚s','ru':'馃嚪馃嚭 袪褍褋褋泻懈泄','ar':'馃嚫馃嚘 丕賱毓乇亘賷丞'};
let html = '';
for(const [code, label] of Object.entries(langs)) {
if(translations[currentUser.id] && translations[currentUser.id][code]) {
html += '<div class=\"translation-item\"><div class=\"lang-label\">'+label+'</div><div class=\"lang-content\">'+translations[currentUser.id][code]+'</div></div>';
}
}
if(html) {
document.getElementById('translatedContent').style.display = 'block';
list.innerHTML = html;
}
}

// 鍒濆鍖栧浘琛?function initCharts() {
drawLineChart('exposureChart', ['鍛ㄤ竴','鍛ㄤ簩','鍛ㄤ笁','鍛ㄥ洓','鍛ㄤ簲','鍛ㄥ叚','鍛ㄦ棩'], [3.2,4.1,3.8,5.2,4.8,6.1,5.5], '#3b82f6');
drawPieChart('platformChart', [12300,8700,5200,2300], ['Facebook','Instagram','LinkedIn','YouTube'], ['#1877f2','#e4405f','#0a66c2','#ff0000']);
drawBarChart('productChart', ['Engine','Strut','Bushing','Control','Ball'], [8.2,6.5,5.8,4.2,3.5], ['#3b82f6','#10b981','#f59e0b','#8b5cf6','#ef4444']);
drawHorizontalBarChart('contentTypeChart', ['浜у搧灞曠ず','瀹㈡埛瑙佽瘉','鎶€鏈创澹?,'琛屼笟娲炲療'], [8.2,6.5,5.1,4.7], '#8b5cf6');
drawBarChart('timeChart', ['6-9','9-12','12-15','15-18','18-21','21-24'], [1.2,3.5,4.8,6.2,5.1,2.8], ['#10b981','#3b82f6','#f59e0b','#ef4444','#8b5cf6','#06b6d4']);
}
// 鏂板姛鑳藉嚱鏁?function selectMessage(id) { console.log('閫夋嫨娑堟伅:', id); }
function sendMessage() { showToast('娑堟伅宸插彂閫?, 'success'); }
function selectCompetitor(id) { console.log('閫夋嫨绔炲搧:', id); }
function editWorkflow(id) { showModal('editWorkflow'); showToast('缂栬緫宸ヤ綔娴?#' + id, 'success'); }
function approve(id) { showToast('瀹℃壒閫氳繃', 'success'); }
function reject(id) { showToast('宸查┏鍥?, 'error'); }
function selectExport(format) { showToast('閫夋嫨瀵煎嚭鏍煎紡: ' + format.toUpperCase(), 'success'); }
function setExportFormat(format) { showToast('璁剧疆瀵煎嚭鏍煎紡: ' + format.toUpperCase(), 'success'); }
function exportData() { hideModal('exportData'); showToast('鏁版嵁瀵煎嚭鎴愬姛锛?, 'success'); }
function followUp(id) { showModal('followUp'); showToast('璺熻繘璇㈢洏 #' + id, 'success'); }
function viewQuote(id) { showModal('viewQuote'); }
function viewOrder(id) { showModal('viewOrder'); }
window.addEventListener('load', initCharts);
window.addEventListener('resize', initCharts);

